public enum StatusTypes {
    buying,
    progress,
    sending,
    done
}

import java.security.MessageDigest;
import java.util.ArrayList;
import java.util.Scanner;


public class Auth {
    String name;
    String lastName;
    String email;
    String password;
    static Auth user;
    int id;
    Cart cart ;
    static ArrayList<Auth> data = new ArrayList<>();
    static ArrayList<Cart> purchaseHistory = new ArrayList<>();

    public Auth(String name, String lastName, String email, String password, int id) {
        this.name = name;
        this.lastName = lastName;
        this.email = email;
        this.password = password;
        this.id = id;
    }

    public static int clientOrAdmin() {
        int inNumber;
        System.out.println("User Type: (Admin: 0, Client: 1)");
        Scanner scanner = new Scanner(System.in);
        inNumber = scanner.nextInt();
        while (inNumber != 0 && inNumber != 1) {
            System.out.println("you can enter just 0 or 1");
            inNumber = scanner.nextInt();
        }
        return inNumber;
    }

    public static void signInOrSignUp() {
        System.out.println("[*] if you are a member of site enter '0' to signIn otherwise enter '1' to signUp:");
        int inNumber;
        Scanner scanner = new Scanner(System.in);
        inNumber = scanner.nextInt();
        while (inNumber != 0 && inNumber != 1) {
            System.out.println("[!] you can enter just 0 or 1");
            inNumber = scanner.nextInt();
        }
        if (inNumber == 1)
            signUp(Auth.clientOrAdmin());
        else
            signIn(Auth.clientOrAdmin());
    }
    public static void signIn(int id) {
        System.out.println("[ SIGN IN ] \nplease enter the credentials below: \n");
        String email;
        String password;
        System.out.println("Email: ");
        Scanner scanner = new Scanner(System.in);
        email = scanner.nextLine();
        System.out.println("Password: ");
        password = scanner.nextLine();
        data.forEach((auth) -> {
            if (auth.email.equals(email) && auth.password.equals(password) && id == auth.id) {
                System.out.println("[*] login successfully");
                auth.user = auth;
            }
        });
    }

    public static void signUp(int id) {
        System.out.println("[ SIGN UP ] \nplease enter the credentials below: \n");
        String name;
        String lastName;
        String email;
        String password;
        System.out.println("Name: ");
        Scanner scanner = new Scanner(System.in);
        name = scanner.nextLine();
        System.out.println("Last Name: ");
        lastName = scanner.nextLine();
        System.out.println("Email: ");
        email = scanner.nextLine();
        System.out.println("Password: ");
        password = sha256(scanner.nextLine());
        data.add(new Auth(name, lastName, email, password, id));
        signIn(Auth.clientOrAdmin());
    }

    public void signOut(){
        Auth.user = null;
    }

    public static String sha256(final String base) {
        try {
            final MessageDigest digest = MessageDigest.getInstance("SHA-256");
            final byte[] hash = digest.digest(base.getBytes("UTF-8"));
            final StringBuilder hexString = new StringBuilder();
            for (int i = 0; i < hash.length; i++) {
                final String hex = Integer.toHexString(0xff & hash[i]);
                if (hex.length() == 1)
                    hexString.append('0');
                hexString.append(hex);
            }
            return hexString.toString();
        } catch (Exception ex) {
            throw new RuntimeException(ex);
        }
    }
    public static void removeUser(String email){
        for (Auth user : data) {
            if(user.id==1){
                if(user.email.equals(email)){
                    data.remove(user);
                    return;
                }
            }
        }
        System.out.println("user not found");
    }
    public static void showListOfUsers(){
        data.forEach((user)->{
            if (user.id==1){
                System.out.println(user);
            }
        });
    }
    public void addPurchaseHistory(Cart cart){
        purchaseHistory.add(cart);
    }
    public void showPurchaseHistory(){
        for (Cart cart:purchaseHistory) {
            System.out.println(cart);
        }
    }
}
import java.util.ArrayList;

public class Product {
    String name;
    String price;
    static ArrayList<Product> products = new ArrayList<>();


    public Product(String name, String price) {
        this.name = name;
        this.price = price;
    }

    public static void showProducts(){
        products.forEach((product -> System.out.println(product)));
    }
    public static void addProduct(String name ,String price){
        Product product = new Product(name, price);
        products.add(product);
    }
    public static void removeProduct(String name){
        products.forEach(product -> {

        });
    }
}
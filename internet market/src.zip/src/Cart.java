import java.util.ArrayList;
import java.util.UUID;



public class Cart {
    ArrayList<Product> products = new ArrayList<>();
    UUID id;
    Auth user;
    StatusTypes status;

    public Cart(Auth auth) {
        status = StatusTypes.buying;
        this.id = UUID.randomUUID();
        this.user = auth;
    }

    /**
     * Adds a product to cart
     * @param product product
     */
    public void addToCart(Product product) {
        this.products.add(product);
    }

    /**
     * Removes a product from cart
     * @param product product
     */
    public void removeFromCart(Product product) {
        this.products.remove(product);
    }

    public void changeStatus(StatusTypes status) {
        this.status = status;
    }
}